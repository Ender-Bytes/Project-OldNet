(function () {
  "use strict";

  document.querySelectorAll(".builder-font").forEach((element) => {
    if (element.classList.contains("builder-font")) {
      element.classList.replace("builder-font", "gotham-font");
    }
  });
})();

//By EpicStuffIsCool/Robyn!!
